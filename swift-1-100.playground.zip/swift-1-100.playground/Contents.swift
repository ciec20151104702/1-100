//: Playground - noun: a place where people can play

import UIKit

/*var i=1,sum=0;
while i<=100
{
    
    sum=sum+i;
    i=i+1;
}

print (sum)
*/


/*var sum=0;
for  i in 0...100
{
    sum=sum+i;

}
print(sum)*/



